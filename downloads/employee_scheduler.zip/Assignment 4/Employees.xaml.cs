﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment04_Start
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class EmployeesWindow : Window
    {

        //declare a field for a List<string> collection
        public List<string> lstEmployees = new List<string>();

        public EmployeesWindow()
        {
            InitializeComponent();

            Load_Data();
        }

        private void Load_Data()
        {
            cboGender.Items.Add("Male");
            cboGender.Items.Add("Female");

            for (decimal decRate=1.0m; decRate<=5.00m; decRate+=.5m)
            {
                cboCommissionRate.Items.Add(decRate.ToString("N1"));
            }
        }

        private void btnEmployeeList_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of the EmployeeList window
            EmployeeListWindow wndEmployeeList = new EmployeeListWindow();

            //load txtEmployeeList TextBox control with string data from List<string> collection
            wndEmployeeList.LoadEmployees(lstEmployees);

            //Call method to display window as a dialog
            wndEmployeeList.ShowDialog();


        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            string strPronoun;

            // Must perform all data validation. Create a method to do this
            if (IsValid() == false) return;

            // Determine if employee is male or female, and what pronouns to use
            if (cboGender.SelectedItem.ToString() == "Male")
            {
                strPronoun = "He";
            }
            else if (cboGender.SelectedItem.ToString() == "Female")
            {
                strPronoun = "She";
            }
            else
            {
                strPronoun = "They";
            }

            //Add employee information to List<string> collection. Make
            //sure you use String.Format or $ string interpolated technique
            lstEmployees.Add($"{txtEmployeeName.Text} starts work in {(DateTime.Parse(txtStartDate.Text) - DateTime.Today).TotalDays} day(s). " +
                $"{strPronoun} will have a commission rate of {cboCommissionRate.SelectedItem.ToString()}.\n");
        }

        // Method to validate user input
        private bool IsValid()
        {          
            bool IsSpace = false;   // Boolean checks if one of the fields has whitespace
            DateTime StartDate;
            string strEmployeeID = txtEmployeeID.Text.Trim(); // Save employee ID in string var and trim whitespaces
            string strEmployeeName = txtEmployeeName.Text.Trim(); // Trim whitespace before or after employee name field

            // --Validate Employee ID--
            // Check if employee ID is present
            if (IsPresent(txtEmployeeID, "Employee ID") == false)
            {
                return false;
            }

            // Check if Employee ID is in the correct format (XX-0099)
            if (txtEmployeeID.Text.Length != 7)
            {
                MessageBox.Show("Employee ID must be the following format: \nXX-9999.", "Check Format", MessageBoxButton.OK, MessageBoxImage.Information);
                txtEmployeeID.Focus();
                return false;
            }

            // Check if first to chars of employee ID are uppercase letters
            foreach(char c in strEmployeeID.Substring(0, 2))
            {
                if (char.IsLetter(c) && char.IsUpper(c) == false)
                {
                    MessageBox.Show("First two letters must be uppercase, check format: \nXX-9999.", "Check Format", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtEmployeeID.Focus();
                    return false;
                }
            }

            //Make sure a dash is between the first two letters and last four digits
            if (strEmployeeID[2] != '-')
            {
                MessageBox.Show("Employee ID must be the following format: \nXX-9999.", "Check Format", MessageBoxButton.OK, MessageBoxImage.Information);
                txtEmployeeID.Focus();
                return false;
            }

            // Check if there are 4 digits in the employee ID
            foreach (char c in strEmployeeID.Substring(3))
            {
                if (char.IsDigit(c) == false)
                {
                    MessageBox.Show("Make sure there are four digits in Employee ID, check format: \nXX-9999.", "Check Format", MessageBoxButton.OK, MessageBoxImage.Information);
                    txtEmployeeID.Focus();
                    return false;
                }
            }

            // --Validate employee name field--
            // Check if employee name is present
            if (IsPresent(txtEmployeeName, "Employee name") == false)
            {
                return false;
            }

            // For loop finds if there is a whitespace in the employee name field
            foreach (char c in strEmployeeName)
            {
                IsSpace = char.IsWhiteSpace(c);
                    
                // Make IsSpace true if loop finds  whitespace in name
                if (IsSpace)
                {
                    break;
                }
            }

            // Raise error if there is no whitespace
            if (IsSpace == false)
            {
                MessageBox.Show("At least one space must be in the employee name field.", "Check Input.", MessageBoxButton.OK, MessageBoxImage.Information);
                txtEmployeeName.Focus();
                return false;
            }

            // --Validate start date field--
            // Check if start date is present
            if (IsPresent(txtStartDate, "Start date") == false)
            {
                return false;
            }

            // Use try parse to check if date time is in the correct formats
            if (DateTime.TryParse(txtStartDate.Text, out StartDate) == false)
            {
                MessageBox.Show("Start date must be the following format: \nmm/dd/yyyy or mm-dd-yyyy", "Check Input.", MessageBoxButton.OK, MessageBoxImage.Information);
                txtStartDate.Focus();
                return false;
            }

            // Make sure start date is greater than today's date
            if (StartDate <= DateTime.Today)
            {
                MessageBox.Show("Start date must be greater than the current date.", "Check Input.", MessageBoxButton.OK, MessageBoxImage.Information);
                txtStartDate.Focus();
                return false;
            }

            // Check if gender combo box is selected
            if (!IsSelected(cboGender, "You must select male or female in gender combo box."))
            {
                return false;
            }

            // Check if commission rate combo box is selected
            if (!IsSelected(cboCommissionRate, "You must select a commission rate in the commission rate combo box."))
            {
                return false;
            }

            return true;
        }

        // Method to checks if a field has any characters
        private bool IsPresent(TextBox textBox, string message)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(message + " is a required field.", "Entry Error.", MessageBoxButton.OK, MessageBoxImage.Information);
                textBox.Focus();
                return false;
            }

            return true;
        }

        // Method to check if combo box item is selected
        private bool IsSelected(ComboBox comboBox, string message)
        {
            if (comboBox.SelectedItem == null)
            {
                MessageBox.Show(message, "Check Input", MessageBoxButton.OK, MessageBoxImage.Information);
                comboBox.Focus();
                return false;
            }

            return true;
        } 

        // Exit button closes window
        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
