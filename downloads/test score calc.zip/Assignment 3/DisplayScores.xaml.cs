﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Assignment03_Start
{
    /// <summary>
    /// Interaction logic for DisplayScores.xaml
    /// </summary>
    public partial class wndDisplayScores : Window
    {
        public int[] ScoresDisplay = new int[21];
        
        
        public wndDisplayScores()
        {
            InitializeComponent();
        }
        public void Load_TestScores()
        {
            //Code a foreach statement that will iterate
            //through the array ScoresDisplay. If the array 
            //element contains a test score greater than 0
            //then add the test score to the ListBox control
            foreach (int score in ScoresDisplay)
            {
                if (score > 0)
                {
                    lstScores.Items.Add(score);
                }                  
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            // Close the window
            this.Close();
        }
    }
}
