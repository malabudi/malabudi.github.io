﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment03_Start
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class wndTestScores : Window
    {
        // Declare array that will contain the test scores
        public int[] intTestScores = new int[21];

        public wndTestScores()
        {
            InitializeComponent();
        }

        //----- Form buttons -------------------------------------------------------------------------------------
        private void btnDescending_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of the WPF window wndDisplayScores
            wndDisplayScores wndDescending = new wndDisplayScores();

            //Code a for statement to loop through each array
            //element of your integer array of test scores. If the
            //test score in your array element is greater than 0 then
            //set ScoresDisplay array element to your array element value.
            //The ScoresDisplay is a public array on the DisplayScores
            //window.
            for (int i = 1; i < intTestScores.Length; i++)
            {
                if (intTestScores[i] > 0)
                {
                    wndDescending.ScoresDisplay[i] = intTestScores[i];
                }
            }

            //Sort the ScoresDisplay array in ascending order
            Array.Sort(wndDescending.ScoresDisplay);

            //Then reverse the array into descending order
            Array.Reverse(wndDescending.ScoresDisplay);

            //Load test scores into list box in the DisplayScores window
            wndDescending.Load_TestScores();

            //Display the DisplayScores window by calling the ShowDialog()
            //method
            wndDescending.ShowDialog();
        }

        private void btnAscending_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of the WPF window wndDisplayScores
            wndDisplayScores wndAscending = new wndDisplayScores();

            //Code a for statement to loop through each array
            //element of your integer array of test scores. If the
            //test score in your array element is greater than 0 then
            //set ScoresDisplay array element to your array element value.
            //The ScoresDisplay is a public array on the DisplayScores
            //window.
            for (int i = 1; i < intTestScores.Length; i++)
            {
                if (intTestScores[i] > 0)
                {
                    wndAscending.ScoresDisplay[i] = intTestScores[i];
                }
            }

            //Sort the ScoresDisplay array in ascending order
            Array.Sort(wndAscending.ScoresDisplay);

            //Load test scores into list box in the DisplayScores window
            wndAscending.Load_TestScores();

            //Display the DisplayScores window by calling the ShowDialog()
            //method
            wndAscending.ShowDialog();

        }

        private void btnAsEntered_Click(object sender, RoutedEventArgs e)
        {
            //Create an instance of the WPF window wndDisplayScores
            wndDisplayScores wndEntered = new wndDisplayScores();

            //Code a for statement to loop through each array
            //element of your integer array of test scores. If the
            //test score in your array element is greater than 0 then
            //set ScoresDisplay array element to your array element value.
            //The ScoresDisplay is a public array on the DisplayScores
            //window.
            for (int i = 1; i < intTestScores.Length; i++)
            {
                if (intTestScores[i] > 0)
                {
                    wndEntered.ScoresDisplay[i] = intTestScores[i];
                }
            }

            //Load test scores into list box in the DisplayScores window
            wndEntered.Load_TestScores();

            //Display the DisplayScores window by calling the ShowDialog()
            //method
            wndEntered.ShowDialog();
        }

        private void btnAddScore_Click(object sender, RoutedEventArgs e)
        {
            // Validate input
            if (IsValid() == false) return;

            int intScore = int.Parse(txtTestScore.Text);

            // Prevent user from adding any more than 20 scores
            int lastIndex = intTestScores.Length - 1;
            if (intTestScores[lastIndex] > 0)
            {
                MessageBox.Show("You can only enter up to 20 test scores.", "Max Test Score Exceeded");
                return;
            }

            // Add score to array of test scores
            for (int i = 1; i < intTestScores.Length; i++)
            {
                if (intTestScores[i] == 0)
                {
                    intTestScores[i] = intScore;
                    break;
                }
            }

            // Enable radio buttons if at least two scores is entered
            if (intTestScores[2] > 0)
            {
                rdoAverage.IsEnabled = true;
                rdoHighest.IsEnabled = true;
                rdoLowest.IsEnabled = true;
                rdoMedian.IsEnabled = true;
            }

            // Clear and focus on text box after user adds score
            txtTestScore.Text = "";
            txtTestScore.Focus();
        }

        //----- Events to calculate test scores -------------------------------------------------------------
        private void rdoAverage_Checked(object sender, RoutedEventArgs e)
        {
            lblResult.Content = Average(intTestScores).ToString();
        }

        private void rdoHighest_Checked(object sender, RoutedEventArgs e)
        {
            lblResult.Content = GetHighest(intTestScores).ToString();
        }

        private void rdoLowest_Checked(object sender, RoutedEventArgs e)
        {
            lblResult.Content = GetLowest(intTestScores).ToString();
        }

        private void rdoMedian_Checked(object sender, RoutedEventArgs e)
        {
            lblResult.Content = Median(intTestScores).ToString();
        }

        //----- Methods to calculate test scores ------------------------------------------------------------
        private double Average(int[] testScores)
        {
            double total = 0;
            int count = 0;

            // Add up total scores
            for (int i = 1; i < testScores.Length; i++)
            {
                total += testScores[i];
            }

            // Add up amount of tests scored
            for (int i = 1; i < testScores.Length; i++)
            {
                if (testScores[i] > 0)
                {
                    count++;
                }
            }

            return Math.Round((double)(total / count), 2);
        }
        
        private int GetHighest(int[] testScores)
        {
            int highest = testScores[1];

            for (int i = 0; i < testScores.Length; i++)
            {
                if (testScores[i] > highest)
                {
                    highest = testScores[i];
                }
            }

            return highest;
        }

        private int GetLowest(int[] testScores)
        {
            int lowest = testScores[1];

            for (int i = 0; i < testScores.Length; i++)
            {
                if (testScores[i] > 0)
                {
                    if (lowest > testScores[i])
                    {
                        lowest = testScores[i];
                    }
                }
            }

            return lowest;
        }

        private double Median(int[] testScores)
        {
            // Create list to hold median values
            List<int> medianList = new List<int>();

            // Add all test scores into the list
            for (int i = 1; i < testScores.Length; i++)
            {
                if (testScores[i] > 0)
                {
                    medianList.Add(testScores[i]);
                }
            }

            // Sort the list from least to greatest and count how many scores there are
            int count = medianList.Count;
            medianList.Sort();

            if (count % 2 == 0) // If there are an even amount of test scores
            {
                double middleFirst = medianList[(count / 2) - 1];
                double middleSecond = medianList[(count / 2)];

                return (middleFirst + middleSecond) / 2;
            }

            return medianList[count / 2]; // If there is an odd amount of test scores
        }

        //----- Methods to validate input -------------------------------------------------------------------
        private bool IsValid()
        {
            return IsPresent(txtTestScore, "Test score") &&
                IsInt32(txtTestScore, "Test score") &&
                IsWithinRange(txtTestScore, "Test score", 1, 100);
        }

        // Check if there is a test score in text box
        private bool IsPresent(TextBox textBox, string name)
        {
            
            if (txtTestScore.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }

            return true;
        }

        // Check if input is an integer type
        private bool IsInt32(TextBox textBox, string name)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be an integer.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        // Check if input is between 0 and 100
        private bool IsWithinRange(TextBox textBox, string name, decimal min, decimal max)
        {
            decimal score = Convert.ToDecimal(textBox.Text);
            if (score < min || score > max)
            {
                MessageBox.Show(name + " must be between " + min + " and " + max + ".", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        //----- Change output when user types input ------------------------------------------------------------------------
        private void txtTestScore_TextChanged(object sender, TextChangedEventArgs e)
        {
            lblResult.Content = "";
        }
    }
}
