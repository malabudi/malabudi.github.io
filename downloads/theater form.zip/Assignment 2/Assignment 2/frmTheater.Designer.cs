﻿
namespace Assignment_2
{
    partial class frmTheater
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.chkDinnerPackage = new System.Windows.Forms.CheckBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.GallerySeatCost = new System.Windows.Forms.Label();
            this.lblGalleryCost = new System.Windows.Forms.Label();
            this.lblFloorFrontCost = new System.Windows.Forms.Label();
            this.FloorFrontCost = new System.Windows.Forms.Label();
            this.lblMezzanineCost = new System.Windows.Forms.Label();
            this.MezzanineCost = new System.Windows.Forms.Label();
            this.lblFloorBackCost = new System.Windows.Forms.Label();
            this.FloorBackCost = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.Label();
            this.lblEventFee = new System.Windows.Forms.Label();
            this.EventFee = new System.Windows.Forms.Label();
            this.lblDinnerCost = new System.Windows.Forms.Label();
            this.DinnerCost = new System.Windows.Forms.Label();
            this.lblVehicleParkCost = new System.Windows.Forms.Label();
            this.VehicleParkingCost = new System.Windows.Forms.Label();
            this.rdoYesParking = new System.Windows.Forms.RadioButton();
            this.rdoNoParking = new System.Windows.Forms.RadioButton();
            this.lstVehiceParking = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFloorFrontRows = new System.Windows.Forms.TextBox();
            this.lblFloorBackRows = new System.Windows.Forms.Label();
            this.txtGallery = new System.Windows.Forms.TextBox();
            this.txtFloorBackRows = new System.Windows.Forms.TextBox();
            this.lblGallery = new System.Windows.Forms.Label();
            this.lblMezzanine = new System.Windows.Forms.Label();
            this.lblFloorFrontRows = new System.Windows.Forms.Label();
            this.txtMezzanine = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(12, 19);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(126, 20);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Customer &name:";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(145, 16);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(136, 26);
            this.txtName.TabIndex = 1;
            this.txtName.TextChanged += new System.EventHandler(this.txtName_TextChanged);
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNumber.Location = new System.Drawing.Point(12, 63);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(117, 20);
            this.lblPhoneNumber.TabIndex = 2;
            this.lblPhoneNumber.Text = "&Phone number:";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNumber.Location = new System.Drawing.Point(145, 57);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(136, 26);
            this.txtPhoneNumber.TabIndex = 3;
            this.txtPhoneNumber.TextChanged += new System.EventHandler(this.txtPhoneNumber_TextChanged);
            // 
            // chkDinnerPackage
            // 
            this.chkDinnerPackage.AutoSize = true;
            this.chkDinnerPackage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDinnerPackage.Location = new System.Drawing.Point(12, 472);
            this.chkDinnerPackage.Name = "chkDinnerPackage";
            this.chkDinnerPackage.Size = new System.Drawing.Size(140, 24);
            this.chkDinnerPackage.TabIndex = 16;
            this.chkDinnerPackage.Text = "&Dinner package";
            this.chkDinnerPackage.UseVisualStyleBackColor = true;
            this.chkDinnerPackage.CheckedChanged += new System.EventHandler(this.chkDinnerPackage_CheckedChanged);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalculate.Location = new System.Drawing.Point(321, 463);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(121, 44);
            this.btnCalculate.TabIndex = 33;
            this.btnCalculate.Text = "C&alculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(458, 463);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(121, 44);
            this.btnClear.TabIndex = 34;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(597, 463);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(121, 44);
            this.btnExit.TabIndex = 35;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // GallerySeatCost
            // 
            this.GallerySeatCost.AutoSize = true;
            this.GallerySeatCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GallerySeatCost.Location = new System.Drawing.Point(338, 19);
            this.GallerySeatCost.Name = "GallerySeatCost";
            this.GallerySeatCost.Size = new System.Drawing.Size(131, 20);
            this.GallerySeatCost.TabIndex = 17;
            this.GallerySeatCost.Text = "Gallery seat cost:";
            // 
            // lblGalleryCost
            // 
            this.lblGalleryCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGalleryCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGalleryCost.Location = new System.Drawing.Point(554, 16);
            this.lblGalleryCost.Name = "lblGalleryCost";
            this.lblGalleryCost.Size = new System.Drawing.Size(131, 23);
            this.lblGalleryCost.TabIndex = 18;
            // 
            // lblFloorFrontCost
            // 
            this.lblFloorFrontCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFloorFrontCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorFrontCost.Location = new System.Drawing.Point(554, 72);
            this.lblFloorFrontCost.Name = "lblFloorFrontCost";
            this.lblFloorFrontCost.Size = new System.Drawing.Size(131, 23);
            this.lblFloorFrontCost.TabIndex = 20;
            // 
            // FloorFrontCost
            // 
            this.FloorFrontCost.AutoSize = true;
            this.FloorFrontCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FloorFrontCost.Location = new System.Drawing.Point(338, 75);
            this.FloorFrontCost.Name = "FloorFrontCost";
            this.FloorFrontCost.Size = new System.Drawing.Size(201, 20);
            this.FloorFrontCost.TabIndex = 19;
            this.FloorFrontCost.Text = "Floor seat cost (rows 1-20):";
            // 
            // lblMezzanineCost
            // 
            this.lblMezzanineCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMezzanineCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMezzanineCost.Location = new System.Drawing.Point(554, 186);
            this.lblMezzanineCost.Name = "lblMezzanineCost";
            this.lblMezzanineCost.Size = new System.Drawing.Size(131, 23);
            this.lblMezzanineCost.TabIndex = 24;
            // 
            // MezzanineCost
            // 
            this.MezzanineCost.AutoSize = true;
            this.MezzanineCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MezzanineCost.Location = new System.Drawing.Point(338, 189);
            this.MezzanineCost.Name = "MezzanineCost";
            this.MezzanineCost.Size = new System.Drawing.Size(159, 20);
            this.MezzanineCost.TabIndex = 23;
            this.MezzanineCost.Text = "Mezzanine seat cost:";
            // 
            // lblFloorBackCost
            // 
            this.lblFloorBackCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFloorBackCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorBackCost.Location = new System.Drawing.Point(554, 130);
            this.lblFloorBackCost.Name = "lblFloorBackCost";
            this.lblFloorBackCost.Size = new System.Drawing.Size(131, 23);
            this.lblFloorBackCost.TabIndex = 22;
            // 
            // FloorBackCost
            // 
            this.FloorBackCost.AutoSize = true;
            this.FloorBackCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FloorBackCost.Location = new System.Drawing.Point(338, 133);
            this.FloorBackCost.Name = "FloorBackCost";
            this.FloorBackCost.Size = new System.Drawing.Size(210, 20);
            this.FloorBackCost.TabIndex = 21;
            this.FloorBackCost.Text = "Floor seat cost (rows 21-40):";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost.Location = new System.Drawing.Point(554, 408);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(131, 23);
            this.lblTotalCost.TabIndex = 32;
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total.Location = new System.Drawing.Point(338, 411);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(82, 20);
            this.Total.TabIndex = 31;
            this.Total.Text = "Total cost:";
            // 
            // lblEventFee
            // 
            this.lblEventFee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEventFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEventFee.Location = new System.Drawing.Point(554, 352);
            this.lblEventFee.Name = "lblEventFee";
            this.lblEventFee.Size = new System.Drawing.Size(131, 23);
            this.lblEventFee.TabIndex = 30;
            // 
            // EventFee
            // 
            this.EventFee.AutoSize = true;
            this.EventFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EventFee.Location = new System.Drawing.Point(338, 355);
            this.EventFee.Name = "EventFee";
            this.EventFee.Size = new System.Drawing.Size(81, 20);
            this.EventFee.TabIndex = 29;
            this.EventFee.Text = "Event fee:";
            // 
            // lblDinnerCost
            // 
            this.lblDinnerCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDinnerCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDinnerCost.Location = new System.Drawing.Point(554, 299);
            this.lblDinnerCost.Name = "lblDinnerCost";
            this.lblDinnerCost.Size = new System.Drawing.Size(131, 23);
            this.lblDinnerCost.TabIndex = 28;
            // 
            // DinnerCost
            // 
            this.DinnerCost.AutoSize = true;
            this.DinnerCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DinnerCost.Location = new System.Drawing.Point(338, 302);
            this.DinnerCost.Name = "DinnerCost";
            this.DinnerCost.Size = new System.Drawing.Size(159, 20);
            this.DinnerCost.TabIndex = 27;
            this.DinnerCost.Text = "Dinner package cost:";
            // 
            // lblVehicleParkCost
            // 
            this.lblVehicleParkCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblVehicleParkCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVehicleParkCost.Location = new System.Drawing.Point(554, 243);
            this.lblVehicleParkCost.Name = "lblVehicleParkCost";
            this.lblVehicleParkCost.Size = new System.Drawing.Size(131, 23);
            this.lblVehicleParkCost.TabIndex = 26;
            // 
            // VehicleParkingCost
            // 
            this.VehicleParkingCost.AutoSize = true;
            this.VehicleParkingCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VehicleParkingCost.Location = new System.Drawing.Point(338, 246);
            this.VehicleParkingCost.Name = "VehicleParkingCost";
            this.VehicleParkingCost.Size = new System.Drawing.Size(155, 20);
            this.VehicleParkingCost.TabIndex = 25;
            this.VehicleParkingCost.Text = "Vehicle parking cost:";
            // 
            // rdoYesParking
            // 
            this.rdoYesParking.AutoSize = true;
            this.rdoYesParking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoYesParking.Location = new System.Drawing.Point(170, 277);
            this.rdoYesParking.Name = "rdoYesParking";
            this.rdoYesParking.Size = new System.Drawing.Size(55, 24);
            this.rdoYesParking.TabIndex = 13;
            this.rdoYesParking.Text = "Yes";
            this.rdoYesParking.UseVisualStyleBackColor = true;
            this.rdoYesParking.CheckedChanged += new System.EventHandler(this.rdoYesParking_CheckedChanged);
            // 
            // rdoNoParking
            // 
            this.rdoNoParking.AutoSize = true;
            this.rdoNoParking.Checked = true;
            this.rdoNoParking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoNoParking.Location = new System.Drawing.Point(234, 277);
            this.rdoNoParking.Name = "rdoNoParking";
            this.rdoNoParking.Size = new System.Drawing.Size(47, 24);
            this.rdoNoParking.TabIndex = 14;
            this.rdoNoParking.TabStop = true;
            this.rdoNoParking.Text = "No";
            this.rdoNoParking.UseVisualStyleBackColor = true;
            this.rdoNoParking.CheckedChanged += new System.EventHandler(this.rdoNoParking_CheckedChanged);
            // 
            // lstVehiceParking
            // 
            this.lstVehiceParking.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstVehiceParking.FormattingEnabled = true;
            this.lstVehiceParking.ItemHeight = 20;
            this.lstVehiceParking.Location = new System.Drawing.Point(12, 316);
            this.lstVehiceParking.Name = "lstVehiceParking";
            this.lstVehiceParking.Size = new System.Drawing.Size(269, 144);
            this.lstVehiceParking.TabIndex = 15;
            this.lstVehiceParking.SelectedIndexChanged += new System.EventHandler(this.lstVehiceParking_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 277);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "&Vehicle Parking:";
            // 
            // txtFloorFrontRows
            // 
            this.txtFloorFrontRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFloorFrontRows.Location = new System.Drawing.Point(213, 144);
            this.txtFloorFrontRows.Name = "txtFloorFrontRows";
            this.txtFloorFrontRows.Size = new System.Drawing.Size(68, 26);
            this.txtFloorFrontRows.TabIndex = 7;
            this.txtFloorFrontRows.TextChanged += new System.EventHandler(this.txtFloorFrontRows_TextChanged);
            // 
            // lblFloorBackRows
            // 
            this.lblFloorBackRows.AutoSize = true;
            this.lblFloorBackRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorBackRows.Location = new System.Drawing.Point(12, 186);
            this.lblFloorBackRows.Name = "lblFloorBackRows";
            this.lblFloorBackRows.Size = new System.Drawing.Size(176, 20);
            this.lblFloorBackRows.TabIndex = 8;
            this.lblFloorBackRows.Text = "Fl&oor seat (rows 21-40):";
            // 
            // txtGallery
            // 
            this.txtGallery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGallery.Location = new System.Drawing.Point(213, 103);
            this.txtGallery.Name = "txtGallery";
            this.txtGallery.Size = new System.Drawing.Size(68, 26);
            this.txtGallery.TabIndex = 5;
            this.txtGallery.TextChanged += new System.EventHandler(this.txtGallery_TextChanged);
            // 
            // txtFloorBackRows
            // 
            this.txtFloorBackRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFloorBackRows.Location = new System.Drawing.Point(213, 189);
            this.txtFloorBackRows.Name = "txtFloorBackRows";
            this.txtFloorBackRows.Size = new System.Drawing.Size(68, 26);
            this.txtFloorBackRows.TabIndex = 9;
            this.txtFloorBackRows.TextChanged += new System.EventHandler(this.txtFloorBackRows_TextChanged);
            // 
            // lblGallery
            // 
            this.lblGallery.AutoSize = true;
            this.lblGallery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGallery.Location = new System.Drawing.Point(12, 100);
            this.lblGallery.Name = "lblGallery";
            this.lblGallery.Size = new System.Drawing.Size(97, 20);
            this.lblGallery.TabIndex = 4;
            this.lblGallery.Text = "&Gallery seat:";
            // 
            // lblMezzanine
            // 
            this.lblMezzanine.AutoSize = true;
            this.lblMezzanine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMezzanine.Location = new System.Drawing.Point(12, 230);
            this.lblMezzanine.Name = "lblMezzanine";
            this.lblMezzanine.Size = new System.Drawing.Size(125, 20);
            this.lblMezzanine.TabIndex = 10;
            this.lblMezzanine.Text = "&Mezzanine seat:";
            // 
            // lblFloorFrontRows
            // 
            this.lblFloorFrontRows.AutoSize = true;
            this.lblFloorFrontRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorFrontRows.Location = new System.Drawing.Point(12, 144);
            this.lblFloorFrontRows.Name = "lblFloorFrontRows";
            this.lblFloorFrontRows.Size = new System.Drawing.Size(167, 20);
            this.lblFloorFrontRows.TabIndex = 6;
            this.lblFloorFrontRows.Text = "&Floor seat (rows 1-20):";
            // 
            // txtMezzanine
            // 
            this.txtMezzanine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMezzanine.Location = new System.Drawing.Point(213, 230);
            this.txtMezzanine.Name = "txtMezzanine";
            this.txtMezzanine.Size = new System.Drawing.Size(68, 26);
            this.txtMezzanine.TabIndex = 11;
            this.txtMezzanine.TextChanged += new System.EventHandler(this.txtMezzanine_TextChanged);
            // 
            // frmTheater
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 520);
            this.ControlBox = false;
            this.Controls.Add(this.txtMezzanine);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblFloorFrontRows);
            this.Controls.Add(this.lstVehiceParking);
            this.Controls.Add(this.lblMezzanine);
            this.Controls.Add(this.rdoNoParking);
            this.Controls.Add(this.lblGallery);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.txtFloorBackRows);
            this.Controls.Add(this.txtGallery);
            this.Controls.Add(this.rdoYesParking);
            this.Controls.Add(this.lblFloorBackRows);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.txtFloorFrontRows);
            this.Controls.Add(this.lblEventFee);
            this.Controls.Add(this.EventFee);
            this.Controls.Add(this.lblDinnerCost);
            this.Controls.Add(this.DinnerCost);
            this.Controls.Add(this.lblVehicleParkCost);
            this.Controls.Add(this.VehicleParkingCost);
            this.Controls.Add(this.lblMezzanineCost);
            this.Controls.Add(this.MezzanineCost);
            this.Controls.Add(this.lblFloorBackCost);
            this.Controls.Add(this.FloorBackCost);
            this.Controls.Add(this.lblFloorFrontCost);
            this.Controls.Add(this.FloorFrontCost);
            this.Controls.Add(this.lblGalleryCost);
            this.Controls.Add(this.GallerySeatCost);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.chkDinnerPackage);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.lblPhoneNumber);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmTheater";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mohamad\'s Sophisticated Theater";
            this.Load += new System.EventHandler(this.frmTheater_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.CheckBox chkDinnerPackage;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label GallerySeatCost;
        private System.Windows.Forms.Label lblGalleryCost;
        private System.Windows.Forms.Label lblFloorFrontCost;
        private System.Windows.Forms.Label FloorFrontCost;
        private System.Windows.Forms.Label lblMezzanineCost;
        private System.Windows.Forms.Label MezzanineCost;
        private System.Windows.Forms.Label lblFloorBackCost;
        private System.Windows.Forms.Label FloorBackCost;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.Label lblEventFee;
        private System.Windows.Forms.Label EventFee;
        private System.Windows.Forms.Label lblDinnerCost;
        private System.Windows.Forms.Label DinnerCost;
        private System.Windows.Forms.Label lblVehicleParkCost;
        private System.Windows.Forms.Label VehicleParkingCost;
        private System.Windows.Forms.RadioButton rdoYesParking;
        private System.Windows.Forms.RadioButton rdoNoParking;
        private System.Windows.Forms.ListBox lstVehiceParking;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFloorFrontRows;
        private System.Windows.Forms.Label lblFloorBackRows;
        private System.Windows.Forms.TextBox txtGallery;
        private System.Windows.Forms.TextBox txtFloorBackRows;
        private System.Windows.Forms.Label lblGallery;
        private System.Windows.Forms.Label lblMezzanine;
        private System.Windows.Forms.Label lblFloorFrontRows;
        private System.Windows.Forms.TextBox txtMezzanine;
    }
}

