﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2
{
    public partial class frmTheater : Form
    {
        public frmTheater()
        {
            InitializeComponent();
        }

        private void frmTheater_Load(object sender, EventArgs e)
        {
            // Load vehicle parking list box items
            for (int i = 0; i <= 5; i++)
            {
                lstVehiceParking.Items.Add(i);
            }

            // Select first item in list box
            lstVehiceParking.SelectedIndex = 0;
        }

        // validate user input in the form otherwise throw an error
        private bool IsValidInput()
        {
            if (
                // Validate name and phone number
                IsTextPresent(txtName, "Customer name") && IsTextPresent(txtPhoneNumber, "Phone number") &&

                // Validate if ticket entries are integer types
                IsInteger(txtGallery, "Gallery seat") &&
                IsInteger(txtFloorFrontRows, "Floor seat (rows 1-20)") &&
                IsInteger(txtFloorBackRows, "Floor seat (rows 21-40)") &&
                IsInteger(txtMezzanine, "Mezzanine seat") &&
                // Validate vehicle parking input
                IsVehicleValid()
                )
            {
                return true;
            }
            return false;
        }

        // Calculate event fee
        private decimal GetEventFee(int TotalTickets)
        {
            decimal decEventFeeCost;
            const decimal EVENT_FEE = 5M;

            // Use switch statement to determine event fee
            switch (TotalTickets)
            {
                case 1: case 2: case 3: case 4:
                    decEventFeeCost = TotalTickets * EVENT_FEE;
                    break;
                default:
                    decEventFeeCost = 0;
                    break;
            }

            return decEventFeeCost;
        }

        // calculate cost of theater form
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Call validate input method 
            if (IsValidInput() == false) return;

            // variables from input fields
            int intGallery;
            int intFloorFrontRows;
            int intFloorBackRows;
            int intMezzanine;
            int intNumVehicles;
            int intTotalTickets; // count total tickets ordererd by user

            // variables for calculation
            decimal decGalleryCost;
            decimal decFloorFrontCost;
            decimal decFloorBackCost;
            decimal decMezzanineCost;
            decimal decVehicalCost;
            decimal decDinnerCost;
            decimal decEventFeeCost;
            decimal decTotalCost;

            //const decimal PARKING_FEE = 10M;

            // Parse input into integer variables, set 0 to empty textbox fields
            if (IsTicketFieldPresent(txtGallery) == true)
            {
                int.TryParse(txtGallery.Text, out intGallery);
            }
            else
            {
                intGallery = 0;
            }

            if (IsTicketFieldPresent(txtFloorFrontRows) == true)
            {
                int.TryParse(txtFloorFrontRows.Text, out intFloorFrontRows);
            }

            else
            {
                intFloorFrontRows = 0;
            }

            if (IsTicketFieldPresent(txtFloorBackRows) == true)
            {
                int.TryParse(txtFloorBackRows.Text, out intFloorBackRows);
            }

            else
            {
                intFloorBackRows = 0;
            }

            if (IsTicketFieldPresent(txtMezzanine) == true)
            {
                int.TryParse(txtMezzanine.Text, out intMezzanine);
            }

            else
            {
                intMezzanine = 0;
            }

            // get number of vehicles selected by the user
            int.TryParse(lstVehiceParking.SelectedItem.ToString(), out intNumVehicles);

            // Add ordered tickets to store total tickets ordered in a variable
            // Also check if total tickets is between 1-8
            intTotalTickets = intGallery + intFloorFrontRows + intFloorBackRows + intMezzanine;
            if (IsTicketAmount(intTotalTickets) == false) return;

            // Calculate ticket costs and event fee
            decGalleryCost = intGallery * 30M;
            decFloorFrontCost = intFloorFrontRows * 55.50M;
            decFloorBackCost = intFloorBackRows * 45.25M;
            decMezzanineCost = intMezzanine * 85M;
            decEventFeeCost = GetEventFee(intTotalTickets);

            // Calculate vehicle parking costs
            decVehicalCost = intNumVehicles * 10M;
            
            // Calculate dinner package if user wants it
            if (chkDinnerPackage.Checked == true)
            {
                decDinnerCost = intTotalTickets * 35M;
            }

            else
            {
                decDinnerCost = 0M;
            }

            // Calcuate the total cost
            decTotalCost = decGalleryCost + decFloorBackCost + decFloorFrontCost + decMezzanineCost + 
                decEventFeeCost + decDinnerCost + decVehicalCost;

            // Display all costs on the form
            lblGalleryCost.Text = decGalleryCost.ToString("C2");
            lblFloorFrontCost.Text = decFloorFrontCost.ToString("C2");
            lblFloorBackCost.Text = decFloorBackCost.ToString("C2");
            lblMezzanineCost.Text = decMezzanineCost.ToString("C2");
            lblVehicleParkCost.Text = decVehicalCost.ToString("C2");
            lblDinnerCost.Text = decDinnerCost.ToString("C2");
            lblEventFee.Text = decEventFeeCost.ToString("C2");
            lblTotalCost.Text = decTotalCost.ToString("C2");
        }

        // Check if the user needs vehicle parking, at least one vehicle parking spot is selected
        private bool IsVehicleValid()
        {
            int number;
            int.TryParse(lstVehiceParking.SelectedItem.ToString(), out number);

            if (rdoNoParking.Checked == true)
            {
                if (number == 0)
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("Select yes if you want vehicle parking.", "Entry Error");
                    lstVehiceParking.Focus();
                    return false;
                }
            }
            else
            {
                if (number == 0)
                {
                    MessageBox.Show("At least one vehicle must be chosen if you want vehicle parking.", "Entry Error");
                    lstVehiceParking.Focus();
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        // Checks if textbox is integer
        private bool IsInteger(TextBox textBox, string message)
        {
            int number = 0;

            if (IsTicketFieldPresent(textBox)) 
            {
                if (int.TryParse(textBox.Text, out number))
                {
                    return true;
                }
                MessageBox.Show(message + " must be an integer or blank.", "Entry Error");
                textBox.Focus();
                return false;
            }

            // Still true because empty string for tickets will mean 0
            return true;
        }

        // Checks if textbox is empty
        private bool IsTicketFieldPresent(TextBox textBox)
        {
            if (textBox.Text == "")
            {
                return false;
            }
            return true;
        }

        private bool IsTextPresent(TextBox textBox, string message)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(message + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }

            return true;
        }

        // Checks if user ordered between 1-8 tickets
        private bool IsTicketAmount(int TotalTickets)
        {
            if (TotalTickets > 8)
            {
                MessageBox.Show("You can only purchase up to 8 tickets.", "Entry Error");
                return false;
            }
            else if (TotalTickets < 1)
            {
                MessageBox.Show("You must purchase at least one ticket.", "Entry Error");
                return false;
            }

            return true;
        }

        // Method that clears all labels in form
        private void ClearOutput()
        {
            lblGalleryCost.Text = "";
            lblFloorFrontCost.Text = "";
            lblFloorBackCost.Text = "";
            lblMezzanineCost.Text = "";
            lblVehicleParkCost.Text = "";
            lblDinnerCost.Text = "";
            lblEventFee.Text = "";
            lblTotalCost.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Exit the application
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear all textboxes
            txtName.Text = "";
            txtPhoneNumber.Text = "";
            txtGallery.Text = "";
            txtFloorFrontRows.Text = "";
            txtFloorBackRows.Text = "";
            txtMezzanine.Text = "";

            // Reset radio buttons, list boxes, and checkbox fields
            rdoYesParking.Checked = false;
            rdoNoParking.Checked = true;
            lstVehiceParking.SelectedIndex = 0;
            chkDinnerPackage.Checked = false;

            // Clear output
            ClearOutput();

            // Focus on first input field
            txtName.Focus();
        }

        // Clear all output if input changes --TEST AND DELETE THIS COMMENT LATER--
        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void txtPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void txtGallery_TextChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void txtFloorFrontRows_TextChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void txtFloorBackRows_TextChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void txtMezzanine_TextChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void rdoYesParking_CheckedChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void rdoNoParking_CheckedChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void lstVehiceParking_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }

        private void chkDinnerPackage_CheckedChanged(object sender, EventArgs e)
        {
            ClearOutput();
        }
    }

}
